#!/usr/bin/env python3
"""Build progressive evidence artifacts and validate review traceability."""
from __future__ import annotations

import json
import math
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

import pandas as pd

from common import file_sha256, load_jsonl, normalize_title, read_csv_optional, read_json, resolve_artifact, write_json, write_jsonl
from evidence_hierarchy import enrich_evidence_source, tier_rank
from science import quality_appraisal
from semantic import validate_semantic
from gap_design import validate_design, validate_gaps
from meta_analysis import validate_meta


CARD_FIELDS = ["研究问题", "理论与概念", "研究设计", "样本与情境", "方法", "主要发现", "机制", "边界条件", "局限", "与当前课题的关系", "反向或矛盾证据"]
POLICY = read_json(Path(__file__).resolve().parents[1] / "assets/evidence_policy.json", {})


def citation_minimum(total: int) -> int:
    if total <= int(POLICY["small_corpus_max"]): return math.ceil(total * float(POLICY["small_corpus_citation_ratio"]))
    legacy_floor = math.ceil(max(int(POLICY["large_corpus_legacy_floor"]), math.sqrt(total) * float(POLICY["large_corpus_sqrt_multiplier"])))
    return min(total, max(legacy_floor, min(int(POLICY["large_corpus_cap"]), math.ceil(total * float(POLICY["large_corpus_enhanced_ratio"])))))


def writing_eligible_records(root: Path, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return the auditable denominator for prose citation coverage.

    In an ``all`` corpus, every record remains in bibliometric analysis, but
    completed semantic screening may establish that homonyms and peripheral
    records cannot support the focal review.  Such records must not inflate a
    prose-citation quota that could only be met by citation stuffing.
    """
    manifest = read_json(root / "manifest.json", {})
    hierarchy_policy = (POLICY.get("source_hierarchy") or {}) | (manifest.get("evidence_hierarchy") or {})
    records = [enrich_evidence_source(record, hierarchy_policy) for record in records]
    records = [record for record in records if record.get("evidence_tier") != "D"]
    semantic_dir = root / "05_evidence/semantic/extractions"
    screened: dict[str, str] = {}
    for path in semantic_dir.glob("*.json") if semantic_dir.exists() else []:
        item = read_json(path, {})
        if item.get("host_review_status") == "completed":
            screened[str(item.get("record_id"))] = str(item.get("relevance") or "").lower()
    if not screened:
        return records
    blocked = ("peripheral", "irrelevant", "homonym", "prohibit")
    eligible_ids = {rid for rid, label in screened.items() if label and not any(token in label for token in blocked)}
    # Use a semantic denominator only after every planned semantic candidate
    # has been screened. Do not depend on the previous citation-target file:
    # doing so creates a circular denominator that changes after reanalysis.
    planned = set()
    for batch in (root / "05_evidence/semantic/batches").glob("batch-*.json"):
        planned.update(x.get("record_id") for x in (read_json(batch, {}).get("tasks") or []) if x.get("record_id"))
    if planned and not planned.issubset(set(screened)):
        return records
    return [record for record in records if record.get("record_id") in eligible_ids]


def topic_citation_quotas(topic_sizes: dict[int, int], total: int) -> dict[int, int]:
    minimum = citation_minimum(total)
    return {
        topic: min(size, max(int(POLICY["minimum_topic_citations"]), math.ceil(size * float(POLICY["small_topic_ratio"]))) if total <= int(POLICY["small_corpus_max"]) else max(int(POLICY["minimum_topic_citations"]), math.ceil(minimum * size / max(total, 1))))
        for topic, size in topic_sizes.items()
    }


def cited_records(text: str, ledger: list[dict[str, Any]]) -> set[str]:
    claim_ids = claim_ids_in_text(text)
    direct = set(re.findall(r"\bR[0-9a-f]{14}\b", text))
    return direct | {rid for claim in ledger if claim.get("claim_id") in claim_ids for rid in claim.get("record_ids") or []}


def claim_ids_in_text(text: str) -> set[str]:
    ids = set(re.findall(r"\bC\d{4}\b", text))
    for left, right in re.findall(r"C(\d{4})\s*[–—-]\s*C(\d{4})", text):
        start, end = int(left), int(right)
        if 0 <= end - start <= 100: ids.update(f"C{x:04d}" for x in range(start, end + 1))
    return ids


def split_embedded_references(text: str) -> tuple[str, str]:
    match = re.search(r"(?m)^##\s+参考文献.*$", text)
    return (text[:match.start()].rstrip(), text[match.start():].strip()) if match else (text.rstrip(), "")


def embedded_reference_ids(reference_text: str) -> list[str]:
    return re.findall(r"<!--\s*record:(R[0-9a-f]{14})\s*-->", reference_text)


def embedded_social_source_ids(reference_text: str) -> list[str]:
    return re.findall(r"<!--\s*source:(SCTX-\d{3,})\s*-->", reference_text)


def normalize_section_heading(value: str) -> str:
    import unicodedata
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    text = re.sub(r"^\s*(?:第[一二三四五六七八九十百]+[章节部分]|\d+(?:\.\d+)*[.、)）]?)\s*", "", text)
    return re.sub(r"[^0-9a-z\u4e00-\u9fff]+", "", text)


def section_specs(text: str) -> list[dict[str, str]]:
    specs = []
    pattern = re.compile(r"(?m)(?:<!--\s*section:([A-Za-z0-9_.-]+)\s*-->[ \t]*\n)?^##\s+(.+?)\s*$")
    for match in pattern.finditer(text):
        specs.append({"section_id": match.group(1) or "", "title": match.group(2).strip(), "normalized": normalize_section_heading(match.group(2))})
    return specs


def approved_review_headings(root: Path) -> list[str]:
    outline = root / "06_review/outline.md"
    if not outline.exists(): return []
    return [row["title"] for row in section_specs(outline.read_text(encoding="utf-8"))]


def unexpected_review_sections(root: Path, body: str) -> list[str]:
    outline = root / "06_review/outline.md"
    if not outline.exists(): return []
    approved = section_specs(outline.read_text(encoding="utf-8")); actual = section_specs(body)
    approved_ids = {x["section_id"] for x in approved if x["section_id"]}
    approved_norm = {x["normalized"] for x in approved}
    from difflib import SequenceMatcher
    unexpected = []
    for row in actual:
        if row["section_id"] and approved_ids:
            if row["section_id"] not in approved_ids: unexpected.append(row["title"])
            continue
        compatible = any(row["normalized"] == value or (min(len(row["normalized"]), len(value)) >= 4 and SequenceMatcher(None, row["normalized"], value).ratio() >= .72) for value in approved_norm)
        if not compatible: unexpected.append(row["title"])
    return unexpected


def _social_sources(root: Path) -> list[dict[str, Any]]:
    rows = load_jsonl(root / "06_review/social_context_sources.jsonl")
    for index, row in enumerate(rows, 1):
        row.setdefault("source_id", f"SCTX-{index:03d}")
    return rows


def _social_apa(row: dict[str, Any]) -> str:
    author = str(row.get("citation_author") or row.get("source_name") or "机构作者").strip()
    year = str(row.get("publication_date") or "n.d.")[:4]
    title = str(row.get("title") or "网络资料").strip().rstrip(".。")
    url = str(row.get("url") or "").strip()
    retrieved = str(row.get("retrieved_at") or "").strip()
    access = f" 检索日期：{retrieved}。" if retrieved else ""
    return re.sub(r"\s+", " ", f"{author}. ({year}). {title}. {url}.{access}").replace("..", ".").strip()


def clean_apa_reference(value: str) -> str:
    """Normalize legacy registry strings without changing bibliographic content."""
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    text = re.sub(r"\.\s+\.(?=\s|$)", ".", text)
    text = re.sub(r"(?<!https:)(?<!http:)\.{2,}", ".", text)
    text = re.sub(r"\s+([,;:])", r"\1", text)
    return text


def clean_introduction_text(text: str) -> str:
    # Audit markers may sit at the beginning of a paragraph.  Horizontal
    # whitespace is removable, but ``\s*`` would also consume the preceding
    # blank lines and collapse the required 8–12 paragraph funnel structure.
    text = re.sub(r"[ \t]*\[role:[a-z-]+\]", "", text, flags=re.I)
    clean = re.sub(r"[ \t]*\[(?:cite:)?[ \t]*(?:C\d{4}|R[0-9a-f]{14}|SCTX-\d{3,})(?:[ \t]*[,;，；][ \t]*(?:C\d{4}|R[0-9a-f]{14}|SCTX-\d{3,}))*[ \t]*\]", "", text, flags=re.I)
    clean = re.sub(r"<!--.*?-->", "", clean, flags=re.S)
    body, references = split_embedded_references(clean)
    body = re.sub(r"(?m)^\s*#{1,6}.*$", "", body).strip()
    clean = body + ("\n\n" + references.strip() if references else "")
    return re.sub(r"\n{3,}", "\n\n", clean).strip() + "\n"


def clean_audit_text(text: str) -> str:
    """Remove internal bindings while preserving review headings and paragraphs."""
    text = re.sub(r"[ \t]*\[role:[a-z-]+\]", "", text, flags=re.I)
    text = re.sub(r"[ \t]*\[(?:cite:)?[ \t]*(?:C\d{4}|R[0-9a-f]{14}|SCTX-\d{3,})(?:[ \t]*[,;，；][ \t]*(?:C\d{4}|R[0-9a-f]{14}|SCTX-\d{3,}))*[ \t]*\]", "", text, flags=re.I)
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    return re.sub(r"\n{3,}", "\n\n", text).strip() + "\n"


def manuscript_path(root: Path, document: str, variant: str = "evidence-aware", clean: bool = False) -> Path:
    if document not in {"review", "introduction"}: raise ValueError("document 必须是 review 或 introduction")
    if variant not in {"evidence-aware", "publication"}: raise ValueError("variant 必须是 evidence-aware 或 publication")
    if variant == "publication":
        return root / "06_review" / f"{document}_publication{'_audit' if not clean else ''}.md"
    if document == "review": return root / "06_review/review_draft.md"
    return root / "06_review" / ("ssci_introduction.md" if clean else "ssci_introduction_audit.md")


def sync_references(root: Path, document: str = "review", draft_path: Path | None = None, variant: str = "evidence-aware") -> dict[str, Any]:
    if document not in {"review", "introduction"}:
        raise ValueError("document 必须是 review 或 introduction")
    default = manuscript_path(root, document, variant)
    path = draft_path or default
    if not path.exists(): raise RuntimeError(f"{document} 正文不存在：{path}")
    text = path.read_text(encoding="utf-8"); body, _ = split_embedded_references(text)
    ledger = load_jsonl(root / "05_evidence/claim_ledger.jsonl")
    used = cited_records(body, ledger)
    registry = {row.get("record_id"): row for row in load_jsonl(root / "05_evidence/reference_registry.jsonl")}
    missing = sorted(used - set(registry))
    if missing: raise RuntimeError(f"参考文献注册表缺少正文引用记录：{missing}")
    rows = sorted((registry[rid] for rid in used), key=lambda row: clean_apa_reference(row.get("apa") or "").casefold())
    social_rows = _social_sources(root) if document == "introduction" else []
    explicit_social = set(re.findall(r"\bSCTX-\d{3,}\b", body))
    # Backward compatibility: registered introduction context sources were
    # created specifically for the first paragraph before source IDs existed.
    used_social = explicit_social or {row["source_id"] for row in social_rows}
    selected_social = [row for row in social_rows if row["source_id"] in used_social]
    lines = [body, "", "## 参考文献", ""]
    if variant == "evidence-aware":
        lines += ["> 以下条目由正文实际使用的审计标记自动同步；APA 细节仍须在最终投稿前核查。", ""]
    combined = [(str(row.get("apa") or "").casefold(), "record", row) for row in rows]
    combined += [(_social_apa(row).casefold(), "source", row) for row in selected_social]
    for _, kind, row in sorted(combined, key=lambda item: item[0]):
        if kind == "source":
            lines += [f"<!-- source:{row['source_id']} -->", _social_apa(row), ""]
            continue
        lines += [f"<!-- record:{row['record_id']} -->", clean_apa_reference(row.get("apa") or ""), ""]
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    clean_path = manuscript_path(root, document, variant, clean=True)
    if document == "introduction" or variant == "publication":
        clean_path.write_text(clean_introduction_text(path.read_text(encoding="utf-8")) if document == "introduction" else clean_audit_text(path.read_text(encoding="utf-8")), encoding="utf-8")
    report = {"document": document, "variant": variant, "draft": str(path), "clean": str(clean_path) if clean_path.exists() else "", "cited_records": len(used), "social_sources": len(selected_social), "embedded_references": len(rows) + len(selected_social), "missing_registry_records": missing}
    suffix = "_publication" if variant == "publication" else ""
    write_json(root / f"07_logs/reference_sync_{document}{suffix}_report.json", report)
    return report


def sync_review_references(root: Path, draft_path: Path | None = None) -> dict[str, Any]:
    """Backward-compatible wrapper for callers created before v6."""
    return sync_references(root, "review", draft_path)


def coverage_targets(records: list[dict[str, Any]], assignments: pd.DataFrame) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    topic_map = dict(zip(assignments.get("record_id", []), assignments.get("topic_id", [])))
    by_topic: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for record in records: by_topic[int(topic_map.get(record["record_id"], 0) or 0)].append(record)
    minimum = citation_minimum(len(records))
    topic_quotas = topic_citation_quotas({topic_id: len(group) for topic_id, group in by_topic.items()}, len(records))
    selected: list[dict[str, Any]] = []
    for topic_id, group in sorted(by_topic.items()):
        quota = topic_quotas[topic_id]
        ranked = sorted(group, key=lambda r: (tier_rank(r), -int(bool((r.get("fulltext") or {}).get("local_path"))), -int(bool(r.get("abstract"))), -max((r.get("citation_counts") or {"": 0}).values()), -(r.get("year") or 0)))
        for r in ranked[:quota]:
            fallback = r.get("evidence_tier") in {"B", "C"}
            selected.append({"record_id": r["record_id"], "topic_id": topic_id, "evidence_tier": r.get("evidence_tier"), "selection_reason": "quota-shortfall-tier-fallback" if fallback else "topic-quota-tier-a", "fallback": fallback})
    seen = {x["record_id"] for x in selected}
    ranked_all = sorted(records, key=lambda r: (tier_rank(r), -int(bool(r.get("abstract"))), -max((r.get("citation_counts") or {"": 0}).values()), -(r.get("year") or 0)))
    for record in ranked_all:
        if len(seen) >= minimum: break
        if record["record_id"] not in seen:
            fallback = record.get("evidence_tier") in {"B", "C"}
            selected.append({"record_id": record["record_id"], "topic_id": int(topic_map.get(record["record_id"], 0) or 0), "evidence_tier": record.get("evidence_tier"), "selection_reason": "quota-shortfall-tier-fallback" if fallback else "overall-coverage-tier-a", "fallback": fallback}); seen.add(record["record_id"])
    summary = {"records": len(records), "minimum_required": minimum, "planned_records": len(seen), "minimum_ratio": .60 if len(records) <= 100 else None, "topic_targets": {str(t): topic_quotas[t] for t in by_topic}, "tier_counts": {str(k): int(v) for k, v in pd.Series([r.get("evidence_tier", "D") for r in records]).value_counts().items()}, "tier_fallbacks": sum(bool(x.get("fallback")) for x in selected)}
    return selected, summary


def _table_dossier(root: Path, filename: str, title: str, tables: list[str]) -> None:
    lines = [f"# {title}", "", "> 计量结果用于组织综述思路，不等同于内容性或因果证据。每项写作判断仍须回到 supporting_documents 与证据卡。", ""]
    for table in tables:
        path = root / "04_analysis/markdown" / f"{table}.md"
        lines += [f"## {table}", "", path.read_text(encoding="utf-8") if path.exists() else "_无可用结果_", ""]
    (root / "05_evidence/dossiers" / filename).write_text("\n".join(lines), encoding="utf-8")


def _computed_analysis_claims(root: Path, start: int) -> list[dict[str, Any]]:
    claims, index = [], start
    specs = [
        ("keyword_bursts", "关键词突现", "term", "supporting_documents"),
        ("phrase_bursts", "上下文短语突现", "term", "supporting_documents"),
        ("structural_hole_opportunities", "结构洞连接机会", "node_a", "supporting_documents"),
        ("citation_bursts", "引用突现", "title", "record_id"),
    ]
    for table, label, value_col, records_col in specs:
        path = root / "04_analysis/tables" / f"{table}.csv"
        if not path.exists(): continue
        frame = read_csv_optional(path, [value_col, records_col]).head(20)
        for _, row in frame.iterrows():
            raw = str(row.get(records_col, "")); record_ids = re.findall(r"R[0-9a-f]{14}", raw)
            if not record_ids: continue
            index += 1
            value = str(row.get(value_col, ""))
            if table == "structural_hole_opportunities": value += f" ↔ {row.get('node_b', '')}"
            claims.append({"claim_id": f"C{index:04d}", "claim": f"{label}信号：{value}。该信号需结合内容证据解释。", "claim_type": "bibliometric", "direction": "descriptive", "strength": "computed", "record_ids": list(dict.fromkeys(record_ids)), "anchors": [f"04_analysis/tables/{table}.csv"], "counterevidence": [], "status": "ready"})
    return claims


def apa_reference(record: dict[str, Any]) -> str:
    raw_names = [a.get("name", "") if isinstance(a, dict) else str(a) for a in record.get("authors") or []]
    names, seen_exact, seen_abbrev = [], set(), set()
    for value in raw_names:
        name = re.sub(r"\s+", " ", str(value)).strip(" ,;")
        if not name: continue
        exact = re.sub(r"\W+", "", name).casefold()
        if exact in seen_exact: continue
        parts = re.findall(r"[A-Za-z]+", name)
        if "," in name:
            surname = name.split(",", 1)[0].strip().casefold(); given = "".join(parts[1:])
        else:
            surname = (parts[-1] if parts else name).casefold(); given = "".join(parts[:-1])
        abbrev = surname + (given[:1].casefold() if given else "")
        is_abbreviated = bool(re.fullmatch(r"[A-Za-z.' -]+,?\s*[A-Za-z. -]{1,5}", name))
        if abbrev in seen_abbrev and is_abbreviated: continue
        names.append(name); seen_exact.add(exact); seen_abbrev.add(abbrev)
    if not names: author = "Unknown author"
    elif len(names) <= 20: author = ", ".join(names[:-1]) + (", & " + names[-1] if len(names) > 1 else names[0])
    else: author = ", ".join(names[:19]) + ", …, " + names[-1]
    year = record.get("year") or "n.d."; title = str(record.get("title") or "Untitled").strip().rstrip(".。"); venue = str(record.get("venue") or "").strip().rstrip(".。")
    csl = csl_record(record); volume = str(csl.get("volume") or "").strip(); issue = str(csl.get("issue") or "").strip(); pages = str(csl.get("page") or "").strip()
    doi = re.sub(r"^https?://(?:dx\.)?doi\.org/", "", str((record.get("ids") or {}).get("doi", "")), flags=re.I).strip()
    parts = [f"{author}.", f"({year}).", f"{title}."]
    if venue:
        publication = venue
        if volume: publication += f", {volume}"
        if issue: publication += f"({issue})"
        if pages: publication += f", {pages}"
        parts.append(f"{publication}.")
    if doi: parts.append(f"https://doi.org/{doi}")
    return clean_apa_reference(" ".join(parts))


def csl_record(record: dict[str, Any]) -> dict[str, Any]:
    authors = []
    for raw in record.get("authors") or []:
        name = str(raw.get("name", "") if isinstance(raw, dict) else raw).strip()
        if not name: continue
        if "," in name: family, given = [x.strip() for x in name.split(",", 1)]
        else:
            parts = name.split(); family, given = (parts[-1], " ".join(parts[:-1])) if len(parts) > 1 else (name, "")
        authors.append({"family": family, "given": given})
    raw_values = {}
    for source in (record.get("raw") or {}).values():
        if not isinstance(source, dict): continue
        for key, value in source.items(): raw_values.setdefault(re.sub(r"[^a-z]", "", str(key).lower()), value)
    def pick(*keys): return next((raw_values.get(re.sub(r"[^a-z]", "", key.lower())) for key in keys if raw_values.get(re.sub(r"[^a-z]", "", key.lower())) not in (None, "")), "")
    ids = record.get("ids") or {}; year = record.get("year")
    return {"id": record.get("record_id"), "type": "article-journal" if record.get("type") in {"article", None, ""} else record.get("type"), "title": record.get("title") or "", "author": authors, "issued": {"date-parts": [[year]]} if year else {}, "container-title": record.get("venue") or "", "volume": str(pick("volume", "vl") or ""), "issue": str(pick("issue", "is") or ""), "page": str(pick("pages", "page", "sp", "ep") or ""), "publisher": str(pick("publisher", "pb") or ""), "DOI": ids.get("doi") or "", "ISSN": ids.get("issn") or "", "ISBN": ids.get("isbn") or ""}


def best_fulltext(record: dict[str, Any], extracted: list[Path]) -> Path | None:
    local = (record.get("fulltext") or {}).get("local_path")
    if local and Path(local).exists(): return Path(local)
    title = normalize_title(record.get("title"))
    if not title: return None
    candidates = [(len(normalize_title(p.stem)), p) for p in extracted if normalize_title(p.stem) and (normalize_title(p.stem) in title or title[:30] in normalize_title(p.stem))]
    return max(candidates)[1] if candidates else None


def card_markdown(record: dict[str, Any], fulltext: Path | None) -> str:
    level = "fulltext" if fulltext else ("abstract" if record.get("abstract") else "metadata")
    authors = "; ".join(a.get("name", "") if isinstance(a, dict) else str(a) for a in record.get("authors") or [])
    lines = [f"# [{record['record_id']}] {record.get('title') or '无题名'}", "", "## 来源", "",
             f"- evidence_level: `{level}`", f"- authors: {authors}", f"- year: {record.get('year') or ''}",
             f"- doi: {(record.get('ids') or {}).get('doi','')}", f"- fulltext_path: `{fulltext or ''}`", ""]
    if record.get("abstract"): lines += ["## 摘要", "", record["abstract"], ""]
    lines += ["## 宿主模型证据提取区", "", "> 仅依据上列摘要或 fulltext_path 指向的文件填写。全文证据必须给出 `[page:n]` 或 `[paragraph:n]` 锚点；不得把待填模板当作证据。", ""]
    for field in CARD_FIELDS: lines += [f"### {field}", "", "<!-- TODO: host-agent -->", ""]
    lines += ["### 可复核证据摘录", "", "- <!-- TODO: [page:n]/[paragraph:n] 简短证据与释义 -->", ""]
    return "\n".join(lines)


def build_evidence(root: Path) -> dict[str, Any]:
    analytic_records = load_jsonl(root / "02_corpus/corpus.jsonl")
    if not analytic_records: raise RuntimeError("缺少 02_corpus/corpus.jsonl，请先 search 或 ingest。")
    supplemental_records = load_jsonl(root / "02_corpus/supplemental_writing_evidence.jsonl")
    records = list(analytic_records)
    seen_record_ids = {record.get("record_id") for record in records}
    records.extend(record for record in supplemental_records if record.get("record_id") not in seen_record_ids)
    manifest = read_json(root / "manifest.json", {})
    hierarchy_policy = (POLICY.get("source_hierarchy") or {}) | (manifest.get("evidence_hierarchy") or {})
    records = [enrich_evidence_source(record, hierarchy_policy) for record in records]
    hierarchy_rows = [{"record_id": r["record_id"], "title": r.get("title", ""), "original_type": r.get("type", ""), "publication_type_normalized": r.get("publication_type_normalized", ""), "peer_review_status": r.get("peer_review_status", ""), "evidence_tier": r.get("evidence_tier", ""), "tier_reason": r.get("tier_reason", ""), "claim_use_roles": "; ".join(r.get("claim_use_roles") or [])} for r in records]
    hierarchy_frame = pd.DataFrame(hierarchy_rows)
    hierarchy_frame.to_csv(root / "05_evidence/evidence_source_hierarchy.csv", index=False, encoding="utf-8-sig")
    (root / "05_evidence/evidence_source_hierarchy.md").write_text("# 文献证据来源分层\n\n> 分层只控制写作候选顺序，不替代论断相关性、研究设计与内容质量判断。\n\n" + hierarchy_frame.to_markdown(index=False) + "\n", encoding="utf-8")
    extracted = list((root / "03_fulltext/extracted").glob("*.md"))
    assignments_path = root / "04_analysis/tables/topic_assignments.csv"
    assignments = read_csv_optional(assignments_path, ["record_id", "topic_id"])
    module_status = read_json(root / "04_analysis/advanced_module_status.json", {})
    nmf_gate = module_status.get("nmf") or {}
    if not nmf_gate.get("structure_allowed", nmf_gate.get("writing_allowed", False)):
        assignments = assignments.iloc[0:0].copy()
    topic_map = dict(zip(assignments.get("record_id", []), assignments.get("topic_id", [])))
    cards_dir = root / "05_evidence/cards"; cards_dir.mkdir(parents=True, exist_ok=True)
    levels, topics = defaultdict(int), defaultdict(list)
    for record in records:
        fulltext = best_fulltext(record, extracted); level = "fulltext" if fulltext else ("abstract" if record.get("abstract") else "metadata")
        levels[level] += 1; topic_id = int(topic_map.get(record["record_id"], 0) or 0); topics[topic_id].append((record, fulltext))
        path = cards_dir / f"{record['record_id']}.md"
        if not path.exists(): path.write_text(card_markdown(record, fulltext), encoding="utf-8")
    dossiers = root / "05_evidence/dossiers"; dossiers.mkdir(parents=True, exist_ok=True)
    for topic_id, items in sorted(topics.items()):
        lines = [f"# Topic {topic_id} evidence dossier", "", f"- documents: {len(items)}", "- status: host-agent synthesis required", "", "## 代表性与覆盖", ""]
        ranked = sorted(items, key=lambda x: (bool(x[1]), max((x[0].get("citation_counts") or {"": 0}).values())), reverse=True)
        for record, fulltext in ranked:
            lines.append(f"- [{record['record_id']}] {record['title']} ({record.get('year') or 'n.d.'}) — {'fulltext' if fulltext else 'abstract/metadata'} — [card](../cards/{record['record_id']}.md)")
        lines += ["", "## 宿主模型综合区", "", "### 共识", "", "<!-- TODO -->", "", "### 分歧与反例", "", "<!-- TODO -->", "", "### 方法和情境边界", "", "<!-- TODO -->"]
        (dossiers / f"topic-{topic_id:02d}.md").write_text("\n".join(lines), encoding="utf-8")
    quality_rows = quality_appraisal(records)
    write_jsonl(root / "05_evidence/study_quality_appraisal.jsonl", quality_rows)
    pd.DataFrame(quality_rows).to_csv(root / "05_evidence/study_quality_appraisal.csv", index=False, encoding="utf-8-sig")
    previous = load_jsonl(root / "05_evidence/claim_ledger.jsonl")
    ledger = []
    topic_table = root / "04_analysis/tables/topics.csv"
    if topic_table.exists() and nmf_gate.get("claim_allowed", nmf_gate.get("writing_allowed", False)):
        for idx, row in read_csv_optional(topic_table, ["topic_id", "documents", "top_terms", "representative_ids"]).iterrows():
            representatives = row.get("representative_ids", "")
            record_ids = str(representatives).split("; ") if pd.notna(representatives) and str(representatives).strip() else []
            ledger.append({"claim_id": f"C{idx+1:04d}", "claim": f"语料中主题 {int(row['topic_id'])} 包含 {int(row['documents'])} 篇文献，主要词为 {row['top_terms']}。", "claim_type": "bibliometric", "direction": "descriptive", "strength": "computed", "record_ids": record_ids, "anchors": ["04_analysis/tables/topics.csv"], "counterevidence": [], "status": "ready"})
    preserved = [c for c in previous if c.get("claim_type") in {"abstract", "fulltext", "metadata"}]
    existing_ids = {c.get("claim_id") for c in ledger}
    for claim in preserved:
        if claim.get("claim_id") not in existing_ids: ledger.append(claim); existing_ids.add(claim.get("claim_id"))
    next_index = max([int(re.sub(r"\D", "", str(c.get("claim_id") or "0")) or 0) for c in ledger] or [0])
    ledger.extend(_computed_analysis_claims(root, max(2000, next_index)))
    for claim in ledger:
        claim.setdefault("study_quality", "not-applicable" if claim.get("claim_type") == "bibliometric" else "not-yet-appraised")
        claim.setdefault("risk_of_bias", "not-applicable" if claim.get("claim_type") == "bibliometric" else "unknown")
        claim.setdefault("independent_sample_status", "unverified")
        claim.setdefault("evidence_scope", "direct" if claim.get("claim_type") in {"fulltext", "abstract"} else "computed-or-host-synthesis")
        claim.setdefault("support_check", "pending")
    write_jsonl(root / "05_evidence/claim_ledger.jsonl", ledger)
    ledger_lines = ["# Claim ledger", "", "> 内容性论断由宿主模型在逐篇证据卡完成后追加；每条必须列 record_ids 与 anchors。", ""]
    for c in ledger: ledger_lines += [f"## [{c['claim_id']}] {c['claim']}", "", f"- 类型：{c['claim_type']}", f"- 文献：{'; '.join(c['record_ids'])}", f"- 锚点：{'; '.join(c['anchors'])}", ""]
    (root / "05_evidence/claim_ledger.md").write_text("\n".join(ledger_lines), encoding="utf-8")
    index = ["# 分节证据索引", "", "宿主模型应逐节读取相关 dossier、claim ledger 和代表性证据卡；不要一次加载全部全文。", "", "## 建议综述结构", "", "1. 研究范围与语料边界", "2. 发展阶段与主题结构", "3. 理论、概念与作用机制", "4. 方法与研究情境", "5. 争议、反例与边界条件", "6. 经证据校准的研究空白", "7. 未来研究议程", "", "## Dossiers", ""]
    index.extend(f"- [Topic {tid}](dossiers/topic-{tid:02d}.md) — {len(items)} documents" for tid, items in sorted(topics.items()))
    (root / "05_evidence/evidence_index.md").write_text("\n".join(index), encoding="utf-8")
    _table_dossier(root, "trend-evidence.md", "趋势与突现证据 dossier", ["keyword_bursts", "phrase_bursts", "topic_trends", "topic_lifecycle", "topic_evolution"])
    _table_dossier(root, "network-evidence.md", "网络、结构洞与桥接证据 dossier", ["network_summary", "network_nodes", "structural_hole_opportunities"])
    _table_dossier(root, "citation-evidence.md", "引用、共引与耦合证据 dossier", ["citation_impact", "citation_bursts", "citation_metrics", "co_citation_edges", "bibliographic_coupling_edges"])
    _table_dossier(root, "strategic-map-evidence.md", "主题战略图证据 dossier", ["strategic_map"])
    _table_dossier(root, "citation-age-evidence.md", "引文年龄与半衰期证据 dossier", ["citation_age_summary", "citation_age_instances", "citation_role_candidates"])
    _table_dossier(root, "knowledge-flow-evidence.md", "跨主题知识流动证据 dossier", ["knowledge_flow_summary", "knowledge_flow_detail"])
    _table_dossier(root, "kmeans-diagnostic.md", "KMeans 异质性诊断（非主题结构）", ["cluster_diagnostics", "kmeans_incremental_cross"])
    for filename, key in (("strategic-map-evidence.md", "strategic_map"), ("citation-age-evidence.md", "citation_age"), ("knowledge-flow-evidence.md", "knowledge_flow"), ("kmeans-diagnostic.md", "kmeans")):
        path = dossiers / filename
        status = module_status.get(key, {})
        path.write_text(path.read_text(encoding="utf-8") + f"\n## 模块门控\n\n```json\n{json.dumps(status, ensure_ascii=False, indent=2)}\n```\n", encoding="utf-8")
    semantic_source = root / "05_evidence/semantic/semantic-synthesis.md"
    semantic_target = dossiers / "semantic-synthesis.md"
    semantic_target.write_text(semantic_source.read_text(encoding="utf-8") if semantic_source.exists() else "# Semantic synthesis\n\n> 尚未运行 build-semantic prepare/compile；不得伪造语义结论。\n", encoding="utf-8")
    eligible_records = writing_eligible_records(root, records)
    eligible_ids = {record["record_id"] for record in eligible_records}
    eligible_assignments = assignments[assignments["record_id"].isin(eligible_ids)] if not assignments.empty else assignments
    targets, coverage = coverage_targets(eligible_records, eligible_assignments)
    coverage["corpus_records"] = len(analytic_records)
    coverage["supplemental_writing_records"] = len(supplemental_records)
    write_jsonl(root / "05_evidence/citation_coverage_targets.jsonl", targets)
    selection_frame = pd.DataFrame(targets)
    selection_frame.to_csv(root / "05_evidence/citation_selection_audit.csv", index=False, encoding="utf-8-sig")
    (root / "05_evidence/citation_selection_audit.md").write_text("# 引用候选选择审计\n\n" + (selection_frame.to_markdown(index=False) if not selection_frame.empty else "_无可写候选_") + "\n", encoding="utf-8")
    coverage_lines = ["# 引用覆盖计划", "", f"- 核心语料：{coverage['records']}", f"- 正文最低独立引用：{coverage['minimum_required']}", f"- 已分配候选：{coverage['planned_records']}", "", "## 主题配额", ""] + [f"- Topic {topic}: {quota}" for topic, quota in sorted(coverage["topic_targets"].items())]
    (root / "05_evidence/citation_coverage.md").write_text("\n".join(coverage_lines), encoding="utf-8")
    section_quota = {"研究范围与演进": .15, "理论与机制": .25, "多源线索与边界": .25, "方法与情境": .15, "争议、空白与议程": .20}
    write_json(root / "05_evidence/section_citation_quotas.json", {name: max(3, math.ceil(coverage["minimum_required"] * share)) for name, share in section_quota.items()})
    ref_lines = ["# APA 7 参考文献注册表", "", "> 自动格式仅作注册与完整性核对；最终交付前由宿主模型核查作者缩写、期刊卷期页码和文献类型。", ""]
    registry = []
    for record in sorted(records, key=lambda r: (str((r.get("authors") or [""])[0]), r.get("year") or 0, r.get("title") or "")):
        apa = apa_reference(record); csl = csl_record(record); missing_bib = [field for field in ("author", "issued", "container-title") if not csl.get(field)]
        registry.append({"record_id": record["record_id"], "apa": apa, "doi": (record.get("ids") or {}).get("doi", ""), "csl": csl, "publication_type_normalized": record.get("publication_type_normalized", ""), "peer_review_status": record.get("peer_review_status", ""), "evidence_tier": record.get("evidence_tier", ""), "tier_reason": record.get("tier_reason", ""), "metadata_status": "complete" if not missing_bib else "incomplete", "missing_fields": missing_bib})
        ref_lines += [f"<!-- record:{record['record_id']} -->", f"- {apa}", ""]
    (root / "06_review/references.md").write_text("\n".join(ref_lines), encoding="utf-8")
    write_jsonl(root / "05_evidence/reference_registry.jsonl", registry)
    pd.DataFrame([{"record_id": x["record_id"], "metadata_status": x["metadata_status"], "missing_fields": "; ".join(x["missing_fields"])} for x in registry]).to_csv(root / "05_evidence/reference_audit.csv", index=False, encoding="utf-8-sig")
    outline = root / "06_review/outline.md"
    if not outline.exists(): outline.write_text("# 文献综述提纲（需用户确认）\n\n> status: draft-not-approved\n\n" + "\n".join(f"<!-- section:SEC-{i:02d} -->\n## {x}\n\n- 本节核心问题：\n- 使用 dossier：\n- 使用 claim IDs：\n- 反例/边界：\n" for i, x in enumerate(["研究范围与语料边界", "发展阶段与主题结构", "理论、概念与作用机制", "方法与研究情境", "争议与边界条件", "研究空白", "未来研究议程"], 1)), encoding="utf-8")
    report = {"records": len(records), "analytic_corpus_records": len(analytic_records), "supplemental_writing_records": len(supplemental_records), "evidence_levels": dict(levels), "evidence_tiers": {str(k): int(v) for k, v in hierarchy_frame["evidence_tier"].value_counts().items()}, "tier_fallbacks": coverage.get("tier_fallbacks", 0), "dossiers": len(topics) + 8, "computed_claims": len(ledger), "quality_appraisals": len(quality_rows), "citation_coverage": coverage, "advanced_modules": module_status, "embedding_used": False}
    write_json(root / "05_evidence/evidence_build_report.json", report); return report


EVIDENCE_TRIGGER = re.compile(r"(?:一些|多项|既有|现有|相关|过去)?(?:研究|文献|语料|证据)(?:表明|显示|发现|指出|提示|呈现|报告|认为)|(?:一些|多项|既有|现有)研究", re.I)


def punctuation_errors(text: str, label: str) -> list[str]:
    checks = [
        (r"[\(（]\s*[;；,，]\s*[\)）]", "空括号内只有标点"),
        (r"[；;]{2,}", "连续分号"),
        (r"[，,]\s*[；;]|[；;]\s*[，,]", "逗号与分号连用"),
        (r"[）)]\s*[，,]\s*[；;]|[）)]\s*[；;]{2,}", "括号后异常标点"),
        (r"\[\s*[,;，；–—-]+\s*\]", "审计标记清理残留"),
        (r"\.\s+\.(?=\s|$)", "参考文献或正文连续句点"),
    ]
    return [f"{label}存在{description}" for pattern, description in checks if re.search(pattern, text)]


def citation_trigger_errors(text: str, ledger: list[dict[str, Any]], label: str) -> list[str]:
    failures = []
    body, _ = split_embedded_references(text)
    for paragraph in [p.strip() for p in re.split(r"\n\s*\n", body) if p.strip() and not p.lstrip().startswith("#")]:
        sentences = [sentence for sentence in re.split(r"(?<=[。！？!?])", paragraph) if sentence.strip()]
        for index, sentence in enumerate(sentences):
            if not EVIDENCE_TRIGGER.search(sentence): continue
            visible_citation = bool(re.search(r"[\(（][^\n\)）]*\b(?:19|20)\d{2}[a-z]?[^\n\)）]*[\)）]", sentence))
            traceable = bool(cited_records(sentence, ledger))
            if not (visible_citation or traceable):
                failures.append(f"{label}证据触发句缺少引用：{sentence[:80]}")
    return failures


def atomic_traceability(root: Path, document: str, source: Path) -> tuple[bool, list[str]]:
    """Require a current audit and complete evidence-bound factual rows."""
    problems: list[str] = []
    report = read_json(root / f"07_logs/writing_audit_{document}.json", {})
    if not report.get("valid") or report.get("status") != "validated": problems.append("逐句审计未通过")
    if not source.exists(): return False, ["正文不存在"]
    if report.get("source_sha256") != file_sha256(source): problems.append("逐句审计正文哈希已过期")
    prose = [row for row in load_jsonl(root / "05_evidence/prose_claim_ledger.jsonl") if row.get("document") == document and row.get("variant", "evidence-aware") == "evidence-aware" and str(row.get("scope") or "final") == "final" and row.get("factual")]
    atomic = [row for row in load_jsonl(root / "05_evidence/prose_atomic_claim_ledger.jsonl") if row.get("document") == document and row.get("variant", "evidence-aware") == "evidence-aware" and str(row.get("scope") or "final") == "final" and row.get("factual", True)]
    if not prose: problems.append("没有事实句审计记录")
    if prose and not atomic: problems.append("没有原子论断审计记录")
    required = ("evidence_level", "claim_scope", "audit_notes")
    for row in prose:
        evidence_ids = row.get("record_ids") or row.get("source_ids") or row.get("claim_ids")
        if row.get("support_status") not in {"supported", "partial"} or not evidence_ids or any(not row.get(field) for field in required):
            problems.append(f"事实句 {row.get('sentence_id')} 证据绑定不完整")
    if atomic and any(row.get("support_status") not in {"supported", "partial"} or not (row.get("record_ids") or row.get("source_ids")) or not row.get("evidence_level") or not row.get("claim_scope") or not row.get("audit_notes") for row in atomic):
        problems.append("原子论断账本存在不完整绑定")
    return not problems, list(dict.fromkeys(problems))


def validate(root: Path) -> dict[str, Any]:
    errors, warnings = [], []
    records = load_jsonl(root / "02_corpus/corpus.jsonl")
    supplemental_records = load_jsonl(root / "02_corpus/supplemental_writing_evidence.jsonl")
    # Supplemental writing evidence is intentionally excluded from NMF and
    # network statistics, but it is part of the prose evidence universe.  Keep
    # separate analytic and writing collections so validation neither changes
    # bibliometric denominators nor mislabels valid prose citations as unknown.
    writing_records = records + supplemental_records
    ids = {r.get("record_id") for r in writing_records}
    manifest_for_tiers = read_json(root / "manifest.json", {})
    hierarchy_policy = (POLICY.get("source_hierarchy") or {}) | (manifest_for_tiers.get("evidence_hierarchy") or {})
    tier_by_id = {r.get("record_id"): enrich_evidence_source(r, hierarchy_policy).get("evidence_tier") for r in writing_records}
    if not records: errors.append("缺少或空的 canonical corpus")
    analytic_ids = {r.get("record_id") for r in records}
    if len(analytic_ids) != len(records): errors.append("record_id 不唯一")
    ledger = load_jsonl(root / "05_evidence/claim_ledger.jsonl"); claim_ids = {c.get("claim_id") for c in ledger}
    module_status = read_json(root / "04_analysis/advanced_module_status.json", {})
    doi_counts = defaultdict(list)
    for record in records:
        doi = (record.get("ids") or {}).get("doi")
        if doi: doi_counts[str(doi).lower()].append(record["record_id"])
    duplicates = {doi: recs for doi, recs in doi_counts.items() if len(recs) > 1}
    if duplicates:
        # Aggregators occasionally attach an issue-, book- or chapter-level
        # DOI to several records with clearly different titles. Preserve and
        # report those metadata conflicts; block only probable duplicate works.
        from difflib import SequenceMatcher
        record_by_id = {r.get("record_id"): r for r in records}
        blocking, conflicts = {}, {}
        for doi, recs in duplicates.items():
            for i in range(len(recs)):
                for j in range(i + 1, len(recs)):
                    left, right = record_by_id[recs[i]], record_by_id[recs[j]]
                    titles = [normalize_title(left.get("title")), normalize_title(right.get("title"))]
                    similarity = SequenceMatcher(None, titles[0], titles[1]).ratio() if all(titles) else 0.0
                    key = f"{doi}::{recs[i]}::{recs[j]}"
                    (blocking if similarity >= 0.9 else conflicts)[key] = {"records": [recs[i], recs[j]], "title_similarity": round(similarity, 4)}
        if blocking: errors.append(f"语料存在重复 DOI 且题名高度相似: {blocking}")
        if conflicts: warnings.append(f"语料存在来源级 DOI 冲突（题名明显不同，未自动删除）: {conflicts}")
    manuscript_used_claim_ids: set[str] = set()
    for manuscript in (root / "06_review/review_draft.md", root / "06_review/ssci_introduction_audit.md", manuscript_path(root, "review", "publication"), manuscript_path(root, "introduction", "publication")):
        if manuscript.exists():
            manuscript_used_claim_ids.update(claim_ids_in_text(manuscript.read_text(encoding="utf-8")))
    for claim in ledger:
        missing = set(claim.get("record_ids") or []) - ids
        if missing: errors.append(f"{claim.get('claim_id')} 引用不存在的记录: {sorted(missing)}")
        if claim.get("claim_type") == "fulltext" and not any(re.search(r"(?:page|paragraph):\d+", str(a)) for a in claim.get("anchors") or []): errors.append(f"{claim.get('claim_id')} 全文论断缺页码/段落锚点")
        if claim.get("support_check") == "unsupported": errors.append(f"{claim.get('claim_id')} 论断—原文支持度检查为 unsupported")
        if claim.get("strength") == "high" and len(set(claim.get("record_ids") or [])) < 3: errors.append(f"{claim.get('claim_id')} 强概括性论断少于 3 篇独立候选研究")
        claim_tiers = {tier_by_id.get(rid, "D") for rid in claim.get("record_ids") or []}
        # Legacy claim-ledger tier checks apply only when the manuscript
        # explicitly invokes that claim ID.  Modern manuscripts bind exact
        # record IDs through the sentence/atomic ledgers; overlapping a record
        # with an unused automatically generated claim must not activate every
        # unrelated legacy claim that happens to include that record.
        claim_is_used = claim.get("claim_id") in manuscript_used_claim_ids
        if claim_is_used and claim.get("strength") in {"high", "strong"} and "A" not in claim_tiers: errors.append(f"{claim.get('claim_id')} 强概括性论断缺少 Tier A 证据")
        if claim_is_used and claim_tiers == {"C"}: errors.append(f"{claim.get('claim_id')} 仅由 Tier C 探索性来源支持")
        if claim_is_used and "D" in claim_tiers and claim.get("direction") not in {"contradict", "mixed"}: errors.append(f"{claim.get('claim_id')} 使用 Tier D 来源支持正向论断")
        anchor_text = " ".join(map(str, claim.get("anchors") or []))
        for marker, module in (("strategic_map", "strategic_map"), ("knowledge_flow", "knowledge_flow"), ("kmeans_", "kmeans"), ("topics.csv", "nmf"), ("topic_assignments", "nmf")):
            blocked = module != "nmf" or claim.get("strength") in {"high", "strong", "computed"}
            gate = module_status.get(module) or {}
            allowed = gate.get("claim_allowed", gate.get("writing_allowed")) if module == "nmf" else gate.get("writing_allowed")
            if marker in anchor_text and blocked and not allowed:
                errors.append(f"{claim.get('claim_id')} 使用未通过写作门控的 {module} 结果")
    retracted = [r.get("record_id") for r in records if (r.get("publication_status") or {}).get("is_retracted")]
    if retracted: warnings.append(f"语料含 {len(retracted)} 篇撤稿标记记录，不得作为正向结论证据: {retracted[:10]}")
    assignments_path = root / "04_analysis/tables/topic_assignments.csv"
    assignments = read_csv_optional(assignments_path, ["record_id", "topic_id"])
    nmf_gate = module_status.get("nmf") or {}
    if not nmf_gate.get("structure_allowed", nmf_gate.get("writing_allowed", False)):
        assignments = assignments.iloc[0:0].copy()
    topic_map = dict(zip(assignments.get("record_id", []), assignments.get("topic_id", [])))
    coverage_rows: list[dict[str, Any]] = []
    def validate_manuscript(path: Path, label: str, audit: bool = True, embedded_references: bool = False):
        if not path.exists(): return
        text = path.read_text(encoding="utf-8"); body, reference_text = split_embedded_references(text) if embedded_references else (text, "")
        used_claims = claim_ids_in_text(body); missing = used_claims - claim_ids
        if missing: errors.append(f"{label}使用未知 claim IDs: {sorted(missing)}")
        used_records = cited_records(body, ledger)
        used_d = sorted(rid for rid in used_records if tier_by_id.get(rid) == "D")
        if used_d: errors.append(f"{label}正文引用 Tier D 不合格来源: {used_d}")
        eligible = writing_eligible_records(root, writing_records); eligible_ids = {r["record_id"] for r in eligible}
        eligible_used = used_records & eligible_ids; minimum = citation_minimum(len(eligible))
        coverage_rows.append({"manuscript": label, "scope": "overall", "topic_id": "", "available": len(eligible), "cited": len(eligible_used), "minimum_required": minimum, "coverage": round(len(eligible_used)/max(len(eligible), 1), 6), "status": "pass" if len(eligible_used) >= minimum else "fail"})
        if len(eligible_used) < minimum: errors.append(f"{label}写作合格证据引用覆盖不足：{len(eligible_used)}/{len(eligible)}，最低要求 {minimum}（全量计量语料 {len(records)}）")
        topic_sizes = {int(topic): sum(rid in eligible_ids and value == topic for rid, value in topic_map.items()) for topic in set(topic_map.values())}
        quotas = topic_citation_quotas(topic_sizes, len(eligible))
        for topic_id in sorted(set(topic_map.values())):
            members = {rid for rid, topic in topic_map.items() if topic == topic_id and rid in eligible_ids}; quota = quotas[int(topic_id)]
            covered = len(members & used_records)
            coverage_rows.append({"manuscript": label, "scope": "topic", "topic_id": int(topic_id), "available": len(members), "cited": covered, "minimum_required": quota, "coverage": round(covered/max(len(members), 1), 6), "status": "pass" if covered >= quota else "fail"})
            if covered < quota: errors.append(f"{label} Topic {int(topic_id)} 引用覆盖不足：{covered}/{len(members)}，最低要求 {quota}")
        registered_ids = {row.get("record_id") for row in load_jsonl(root / "05_evidence/reference_registry.jsonl")}
        if not registered_ids and (root / "06_review/references.md").exists():
            registered_ids = set(re.findall(r"<!--\s*record:(R[0-9a-f]{14})\s*-->", (root / "06_review/references.md").read_text(encoding="utf-8")))
        absent = [rid for rid in used_records if rid not in registered_ids]
        if absent: errors.append(f"{label}参考文献注册表缺失记录: {sorted(absent)}")
        if embedded_references:
            embedded = embedded_reference_ids(reference_text); embedded_set = set(embedded)
            if not reference_text: errors.append(f"{label}缺少正文内嵌参考文献段")
            if len(embedded) != len(embedded_set): errors.append(f"{label}文末存在重复参考文献 record 标记")
            if used_records - embedded_set: errors.append(f"{label}文内引用未列入文末参考文献: {sorted(used_records-embedded_set)}")
            if embedded_set - used_records: errors.append(f"{label}文末包含正文未引用文献: {sorted(embedded_set-used_records)}")
            if label.startswith("SSCI 绪论"):
                registered_social = {row["source_id"] for row in _social_sources(root)}
                used_social = set(re.findall(r"\bSCTX-\d{3,}\b", body)) or registered_social
                embedded_social = embedded_social_source_ids(reference_text); embedded_social_set = set(embedded_social)
                if len(embedded_social) != len(embedded_social_set): errors.append("绪论文末存在重复社会背景来源")
                if used_social != embedded_social_set: errors.append(f"绪论社会背景来源与文末集合不一致：正文={sorted(used_social)} 文末={sorted(embedded_social_set)}")
            forbidden = re.findall(r"(?im)^#{2,6}\s+.*(?:扩展主题证据|扩展证据|补充引用|引用扩展).*$", body)
            if forbidden: errors.append(f"{label}包含后置引用填充章节: {forbidden}")
            unexpected = unexpected_review_sections(root, body)
            if unexpected: errors.append(f"{label}包含未获提纲批准的章节: {unexpected}")
            for heading, content in re.findall(r"(?ms)^##\s+(.+?)\s*\n(.*?)(?=^##\s+|\Z)", body):
                section_records = cited_records(content, ledger)
                coverage_rows.append({"manuscript": label, "scope": "section", "topic_id": heading.strip(), "available": len(records), "cited": len(section_records), "minimum_required": 2, "coverage": round(len(section_records)/max(len(records), 1), 6), "status": "pass" if len(section_records) >= 2 else "fail"})
                if len(section_records) < 2: errors.append(f"{label}章节“{heading.strip()}”引用过少：{len(section_records)}，最低要求 2")
                if re.search(r"主题|知识结构|热点", heading):
                    for index, paragraph in enumerate(re.split(r"\n\s*\n", content), 1):
                        plain = paragraph.strip()
                        if len(re.findall(r"[\u4e00-\u9fff]", plain)) >= 40 and not cited_records(plain, ledger):
                            errors.append(f"{label}主题章节“{heading.strip()}”第{index}段缺少相关文献")
            # NMF 主题常以“第一主题……”等段落呈现，而非另设三级标题；逐段强制绑定相关证据。
            for paragraph in re.split(r"\n\s*\n", body):
                plain = paragraph.strip()
                if re.match(r"^第[一二三四五六七八九十]+主题", plain) and not cited_records(plain, ledger):
                    errors.append(f"{label}知识主题段落缺少相关文献：{plain[:50]}")
        errors.extend(citation_trigger_errors(body, ledger, label))
        errors.extend(punctuation_errors(body, label))
        if "TODO" in body: warnings.append(f"{label}仍含 TODO")
        if re.search(r"从未(?:有|被)?研究|完全空白|没有任何研究|never been studied|no studies have", body, flags=re.I): warnings.append(f"{label}含绝对化 gap 表述")
        return used_records
    draft = root / "06_review/review_draft.md"
    if draft.exists():
        text = draft.read_text(encoding="utf-8"); body, _ = split_embedded_references(text); used = claim_ids_in_text(body)
        validate_manuscript(draft, "综述", embedded_references=True)
        # v8+ manuscripts may bind evidence through the finer-grained atomic
        # prose ledger instead of embedding legacy C#### claim identifiers in
        # every sentence.  A validated, evidence-bound atomic ledger provides
        # the same (and more precise) traceability, so do not emit a false
        # migration warning for those manuscripts.
        atomically_traceable, trace_problems = atomic_traceability(root, "review", draft)
        if not used and not atomically_traceable:
            message = "正文未使用 claim ID，且新版逐句/原子证据追溯未完整通过：" + "；".join(trace_problems)
            if read_json(root / "manifest.json", {}).get("writing_audit_required"): errors.append(message)
            else: warnings.append(message)
        contrad = {c.get("claim_id") for c in ledger if c.get("direction") in {"contradict", "mixed"} or c.get("counterevidence")}
        if contrad and not (used & contrad): warnings.append("正文未使用 claim ledger 中的反向/混合证据")
    else: warnings.append("尚未生成 review_draft.md（在语料与提纲确认前这是正常状态）")
    intro_audit = root / "06_review/ssci_introduction_audit.md"; intro_clean = root / "06_review/ssci_introduction.md"
    if intro_audit.exists(): validate_manuscript(intro_audit, "SSCI 绪论", embedded_references=True)
    if intro_clean.exists():
        clean = intro_clean.read_text(encoding="utf-8").strip()
        clean_body, clean_references = split_embedded_references(clean)
        if re.search(r"(?m)^\s*#{1,6}\s|^\s*[-*+]\s|^\s*\d+[.)]\s", clean_body): errors.append("SSCI 绪论清洁版正文不得含小标题、列表或编号")
        paragraphs = [p for p in re.split(r"\n\s*\n", clean_body) if p.strip()]
        if not 8 <= len(paragraphs) <= 12: errors.append(f"SSCI 绪论应为 8–12 个连续自然段，当前 {len(paragraphs)} 段")
        cjk = len(re.findall(r"[\u4e00-\u9fff]", clean_body))
        if not 3000 <= cjk <= 5000: errors.append(f"SSCI 绪论中文长度应为 3000–5000 字，当前约 {cjk} 字")
        if not clean_references: errors.append("SSCI 绪论清洁版缺少文末参考文献")
        if re.search(r"\bC\d{4}\b|\bR[0-9a-f]{14}\b|\bSCTX-\d{3,}\b", clean): errors.append("SSCI 绪论清洁版仍含内部审计 ID")
        errors.extend(punctuation_errors(clean, "SSCI 绪论清洁版"))
    publication_paths = {"review": manuscript_path(root, "review", "publication"), "introduction": manuscript_path(root, "introduction", "publication")}
    for document, path in publication_paths.items():
        if path.exists(): validate_manuscript(path, "综述投稿版" if document == "review" else "SSCI 绪论投稿版", embedded_references=True)
    publication_intro_clean = manuscript_path(root, "introduction", "publication", clean=True)
    if publication_intro_clean.exists():
        clean = publication_intro_clean.read_text(encoding="utf-8").strip(); clean_body, clean_references = split_embedded_references(clean)
        paragraphs = [p for p in re.split(r"\n\s*\n", clean_body) if p.strip() and not p.lstrip().startswith("#")]
        if not 8 <= len(paragraphs) <= 12: errors.append(f"SSCI 绪论投稿版应为 8–12 个连续自然段，当前 {len(paragraphs)} 段")
        if not clean_references: errors.append("SSCI 绪论投稿版缺少文末参考文献")
        if re.search(r"\bC\d{4}\b|\bR[0-9a-f]{14}\b|\bSCTX-\d{3,}\b", clean): errors.append("SSCI 绪论投稿版仍含内部审计 ID")
        errors.extend(punctuation_errors(clean, "SSCI 绪论投稿版"))
    semantic_files = list((root / "05_evidence/semantic/extractions").glob("*.json"))
    completed_semantic = {p.stem for p in semantic_files if read_json(p, {}).get("host_review_status") == "completed"}
    planned_semantic = set()
    for batch in (root / "05_evidence/semantic/batches").glob("batch-*.json"):
        planned_semantic.update(task.get("record_id") for task in (read_json(batch, {}).get("tasks") or []) if task.get("record_id"))
    pending_semantic = planned_semantic - completed_semantic
    if pending_semantic: warnings.append(f"计划候选中仍有 {len(pending_semantic)} 篇待宿主语义提取")
    manifest = read_json(root / "manifest.json", {}); v5_enforced = bool(manifest.get("v5_workflow_enforced"))
    if v5_enforced and draft.exists() and not (root / "06_review/review_brief.json").exists(): errors.append("综述写作前缺少 review_brief.json")
    if v5_enforced and intro_audit.exists():
        if not (root / "06_review/introduction_brief.json").exists(): errors.append("绪论写作前缺少 introduction_brief.json")
        social = load_jsonl(root / "06_review/social_context_sources.jsonl")
        if not social or not all(x.get("url") and x.get("retrieved_at") for x in social): errors.append("绪论第一段缺少可核验现实社会背景来源登记")
    briefs = [read_json(root / "06_review/review_brief.json", {}), read_json(root / "06_review/introduction_brief.json", {})]
    if v5_enforced and any(x.get("model_package_requested") for x in briefs if x):
        # v7+ stores design outputs with the other design-audit artifacts.  Keep
        # accepting the legacy review-folder location so historical tasks remain
        # reproducible after schema migration.
        package = resolve_artifact(root, "theory_model_package")
        if not package.exists(): errors.append("写作简报要求完整理论模型包，但 theory_model_package.md 不存在")
        else:
            package_text = package.read_text(encoding="utf-8")
            required_terms = ("变量", "理论", "假设", "mermaid", "证据等级", "推断目标", "设计", "数据", "主要方法", "替代", "识别假设", "不能回答")
            if not all(term.lower() in package_text.lower() for term in required_terms): errors.append("理论模型包缺少缺口/变量/理论/设计/方法适配/识别假设等必要要素")
            if re.search(r"(?s)方法(?:对应|适配).{0,200}PLS-SEM.{0,200}ANN.{0,200}fsQCA", package_text, re.I): warnings.append("理论模型包疑似仍将PLS-SEM、ANN和fsQCA作为固定默认组合")
    coverage_frame = pd.DataFrame(coverage_rows)
    if not coverage_frame.empty:
        coverage_frame.to_csv(root / "05_evidence/citation_coverage.csv", index=False, encoding="utf-8-sig")
        (root / "05_evidence/citation_coverage_actual.md").write_text("# 实际引用覆盖\n\n" + coverage_frame.to_markdown(index=False) + "\n", encoding="utf-8")
    semantic_dir = root / "05_evidence/semantic/extractions"
    semantic_report = None
    if semantic_dir.exists() and any(semantic_dir.glob("*.json")):
        semantic_report = validate_semantic(root); errors.extend(semantic_report["errors"]); warnings.extend(semantic_report["warnings"])
    gap_report = validate_gaps(root) if (root / "05_evidence/gaps/gap_ledger.jsonl").exists() else None
    if gap_report:
        errors.extend(gap_report["errors"]); warnings.extend(gap_report["warnings"])
    design_report = validate_design(root) if (root / "05_evidence/design/method_recommendations.jsonl").exists() else None
    if design_report:
        errors.extend(design_report["errors"]); warnings.extend(design_report["warnings"])
    meta_report = validate_meta(root) if (root / "05_evidence/meta/effect_sizes.jsonl").exists() else None
    if meta_report:
        errors.extend(meta_report["errors"]); warnings.extend(meta_report["warnings"])
    writing_reports = {}
    for document, variant in (("review", "evidence-aware"), ("introduction", "evidence-aware"), ("review", "publication"), ("introduction", "publication")):
        suffix = "_publication" if variant == "publication" else ""
        item = read_json(root / f"07_logs/writing_audit_{document}{suffix}.json", {})
        source = manuscript_path(root, document, variant)
        if item:
            current_hash = __import__("hashlib").sha256(source.read_bytes()).hexdigest() if source.exists() else ""
            if item.get("source_sha256") and item.get("source_sha256") != current_hash: errors.append(f"{document}-{variant}逐句写作审计已过期，请重新运行audit-writing")
            writing_reports[document if variant == "evidence-aware" else f"{document}_publication"] = item; errors.extend(item.get("errors") or []); warnings.extend(item.get("warnings") or [])
        elif manifest.get("writing_audit_required") and source.exists():
            errors.append(f"{document}-{variant}缺少逐句写作证据审计")
    eligible_count = len(writing_eligible_records(root, writing_records))
    manuscript_paths = {"review": manuscript_path(root, "review"), "introduction": manuscript_path(root, "introduction"), "review_publication": manuscript_path(root, "review", "publication"), "introduction_publication": manuscript_path(root, "introduction", "publication")}
    source_hashes = {name: file_sha256(path) for name, path in manuscript_paths.items() if path.exists()}
    report = {"valid": not errors, "errors": list(dict.fromkeys(errors)), "warnings": list(dict.fromkeys(warnings)), "records": len(records), "writing_eligible_records": eligible_count, "claims": len(ledger), "minimum_citations": citation_minimum(eligible_count), "citation_coverage_rows": len(coverage_rows), "advanced_modules": module_status, "semantic_validation": semantic_report, "gap_validation": gap_report, "design_validation": design_report, "meta_validation": meta_report, "writing_audits": writing_reports, "source_hashes": source_hashes}
    write_json(root / "07_logs/validation_report.json", report); return report


def write_introduction(root: Path, audit_source: Path | None = None) -> dict[str, Any]:
    outline = root / "06_review/outline.md"
    if not outline.exists() or "status: approved" not in outline.read_text(encoding="utf-8"):
        raise RuntimeError("综述提纲尚未获用户确认，不能生成 SSCI 绪论。")
    audit_path = root / "06_review/ssci_introduction_audit.md"
    clean_path = root / "06_review/ssci_introduction.md"
    if audit_source:
        text = audit_source.read_text(encoding="utf-8")
        audit_path.write_text(text, encoding="utf-8")
        sync_report = sync_references(root, "introduction", audit_path)
        synced = audit_path.read_text(encoding="utf-8")
        clean_path.write_text(clean_introduction_text(synced), encoding="utf-8")
        return {"status": "written", "audit": str(audit_path), "clean": str(clean_path), "reference_sync": sync_report}
    targets = load_jsonl(root / "05_evidence/citation_coverage_targets.jsonl")
    records = load_jsonl(root / "02_corpus/corpus.jsonl")
    eligible = writing_eligible_records(root, records)
    minimum = citation_minimum(len(eligible))
    brief = ["# SSCI 漏斗型绪论写作任务", "", "> 由宿主模型据此撰写 8–12 个无小标题连续段落；可见 APA 引文后使用 `[cite:R...,R...]` 绑定证据，完成后用 write-introduction --audit-source 自动同步参考文献并清洁。", "", f"语料总数：{len(records)}", f"语义筛选后可写证据：{len(eligible)}", f"最低独立引用：{minimum}", "", "## 必须读取", "", "- 研究现状地图与已确认提纲", "- topic dossiers", "- trend-evidence.md", "- network-evidence.md", "- citation-evidence.md", "- citation_coverage_targets.jsonl", "", "## 候选记录", ""]
    brief.extend(f"- {x['record_id']} — Topic {x['topic_id']} — {x['selection_reason']}" for x in targets)
    path = root / "06_review/ssci_introduction_brief.md"; path.write_text("\n".join(brief), encoding="utf-8")
    return {"status": "brief-created", "brief": str(path), "corpus_records": len(records), "writing_eligible_records": len(eligible), "minimum_citations": minimum}
